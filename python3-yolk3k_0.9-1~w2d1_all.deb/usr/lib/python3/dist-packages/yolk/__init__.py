"""yolk.

Author: Rob Cakebread <cakebread at gmail>

License  : BSD

"""

__version__ = '0.9'
