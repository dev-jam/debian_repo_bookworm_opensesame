import sys
from . import cli
sys.exit(cli.main())
