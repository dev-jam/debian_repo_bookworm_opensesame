"""Extension to integrate OSWeb into OpenSesame"""

__version__ = '2.0.4.1'
# The name of the package to check for updates on conda and pip
packages = ['opensesame-extension-osweb']
