LICENSE
==========

Experiment Manager Plug-in is distributed under the terms of the GNU General Public License 3.
The full license should be included in the file COPYING, or can be obtained from

- <http://www.gnu.org/licenses/gpl.txt>

Experiment Manager contains works of others. For the full license information, please
refer to `README`.
