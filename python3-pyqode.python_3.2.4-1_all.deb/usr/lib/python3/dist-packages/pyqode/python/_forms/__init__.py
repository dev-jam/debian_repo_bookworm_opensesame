# -*- coding: utf-8 -*-
"""
This packages contains the qt forms and resource files used in
pyqode.python.

To update an forms/rc file, just run the compile_ui script.

"""
