<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Experiment started in external browser</source>
        <translation>在外部浏览器中启动了实验</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Save as…</source>
        <translation>另存为…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>OSWeb and JATOS control panel</source>
        <translation>OSWeb 和 JATOS 控制面板</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Publish to JATOS</source>
        <translation>发布到 JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Publish to MindProbe</source>
        <translation>发布到 MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Create online experiments</source>
        <translation>创建在线实验</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Open from MindProbe</source>
        <translation>从 MindProbe 打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Please specify a JATOS server and API token</source>
        <translation>请指定 JATOS 服务器和 API 令牌</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Experiment succesfully exported</source>
        <translation>实验成功导出</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Open from JATOS</source>
        <translation>从 JATOS 打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Experiment has been published to JATOS</source>
        <translation>实验已发布到 JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Select OSWeb results file…</source>
        <translation>选择 OSWeb 结果文件…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Export JATOS study…</source>
        <translation>导出 JATOS 研究…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="121" />
        <source>Actions</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="166" />
        <source>Experiment properties</source>
        <translation>实验属性</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="184" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;选择 OSWeb 后端在浏览器中运行&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="200" />
        <source>Open from JATOS</source>
        <translation>从 JATOS 打开</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="212" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;直接从 JATOS 下载实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="225" />
        <source>Publish to JATOS</source>
        <translation>发布到 JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="237" />
        <source>&lt;small  style="color:#78909c"&gt;Upload experiment directly to JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;直接将实验上传到 JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="250" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>将 OSWeb 结果转换为 .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="262" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将 JATOS 结果文件转换为电子表格格式&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="290" />
        <source>Import from JATOS archive</source>
        <translation>从 JATOS 存档导入</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="303" />
        <source>Export to JATOS archive</source>
        <translation>导出到 JATOS 存档</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="316" />
        <source>Export to HTML</source>
        <translation>导出为HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="328" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;从 jzip 文件打开实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="340" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将实验保存为 jzip 文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="352" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将实验保存为独立的 html 文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb和JATOS控制面板&lt;/b&gt;&lt;br /&gt;在线实验和JATOS同步的选项</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="96" />
        <source>&lt;h2 style="color:#78909c"&gt;&amp;#x1F6C8; To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;&amp;#x1F6C8; 要直接将实验发布到 JATOS，请在下面指定服务器和 API 令牌&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Embeds custom HTML</source>
        <translation>嵌入自定义 HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>An HTML editor widget</source>
        <translation>一个HTML编辑器小部件</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>HTML editor</source>
        <translation>HTML 编辑器</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Executes JavaScript code</source>
        <translation>执行 JavaScript 代码</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>可能的被试编号</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;即使兼容性检查失败也运行实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;出现在 OSWeb 欢迎屏幕上。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>显示 OSWeb 欢迎屏幕</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;实验开始时加载&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>跳过兼容性检查</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>欢迎文字</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;只在导出时适用&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>切勿提供个人或敏感信息，如信用卡号或 PIN 码。点击或触摸屏幕开始！</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>每行一个 URL</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>外部库</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;用于可靠的媒体播放&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>将浏览器设为全屏</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS</source>
        <translation>JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS UUID</source>
        <translation>JATOS UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="294" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;访问&lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt;申请免费账户&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="301" />
        <source>JATOS server</source>
        <translation>JATOS 服务器</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="314" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="327" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="339" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;在 JATOS 上标识实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="349" />
        <source>undefined</source>
        <translation>未定义</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="356" />
        <source>JATOS API token</source>
        <translation>JATOS API 令牌</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="371" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;来自JATOS用户配置文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="399" />
        <source>Clear UUID</source>
        <translation>清除 UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;重置实验和 JATOS 之间的链接&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>将背景色应用于整个浏览器标签页</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;&amp;#x1F6C8; OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;&amp;#x1F6C8; OSWeb 是一个用于在网页浏览器中运行 OpenSesame 实验的 JavaScript 库。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="389" />
        <source>&lt;small  style="color:#78909c"&gt;&amp;#x1F6C8; JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;&amp;#x1F6C8; JATOS 是用于管理在线实验的服务器软件。您需要在 JATOS 服务器上，例如 mindprobe.eu，上拥有一个帐户，才能在线运行实验。您需要输入 JATOS API 令牌才能将 OpenSesame 连接到 JATOS。请访问 OpenSesame 文档获取说明。&lt;/small&gt;</translation>
    </message>
</context>
</TS>