"""OpenSesame core extensions"""

# The name of the packages to check for updates on conda and pip
packages = ['opensesame-plugin-media_player_mpy',
            'opensesame-plugin-media-player-mpy']
