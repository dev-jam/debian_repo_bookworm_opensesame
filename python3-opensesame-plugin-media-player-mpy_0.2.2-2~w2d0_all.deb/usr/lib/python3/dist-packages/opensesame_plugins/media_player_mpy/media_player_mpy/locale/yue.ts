<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_media_player_mpy</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Media player based on moviepy</source>
        <translation>基於moviepy的媒體播放器</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Play audio</source>
        <translation>播放音訊</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Custom Python code (See Help for more information)</source>
        <translation>自定義Python程式碼（查看幫助以獲得更多資訊）</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Duration</source>
        <translation>持續時間</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Fit video to screen</source>
        <translation>將影片調整至螢幕大小</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Restart the video after it ends</source>
        <translation>影片結束後重新播放</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Specify how you would like to handle events like mouse clicks or keypresses. When set, this overrides the Duration attribute</source>
        <translation>指定您希望如何處理鼠標點擊或按鍵等事件。設定時，此規定會覆蓋「持續時間」的屬性</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Video file</source>
        <translation>影片檔案</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Maintains the aspect ratio</source>
        <translation>維持長寬比</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Call custom Python code</source>
        <translation>呼叫自訂Python程式碼</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>When to call custom event handling code (if any)</source>
        <translation>何時呼叫自訂的事件處理程式碼（如果有的話）</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>The library to use for sound rendering (recommended: sounddevice)</source>
        <translation>用於聲音渲染的函式庫（推薦：sounddevice）</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Copyright (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;b&gt;Media Player OpenSesame 插件，版權所有 (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Loop</source>
        <translation>循環</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Sound renderer</source>
        <translation>聲音渲染器</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Visual stimuli</source>
        <translation>視覺刺激</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A value in milliseconds, 'sound', 'mouseclick', or 'keypress'</source>
        <translation>以毫秒為單位的值，'sound'，'mouseclick'或者'keypress'</translation>
    </message>
</context>
</TS>