<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_media_player_mpy</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Media player based on moviepy</source>
        <translation>Mediaspeler gebaseerd op moviepy</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Play audio</source>
        <translation>Speel audio af</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Custom Python code (See Help for more information)</source>
        <translation>Aangepaste Python-code (Zie Help voor meer informatie)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Duration</source>
        <translation>Duur</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Fit video to screen</source>
        <translation>Video aan scherm aanpassen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Restart the video after it ends</source>
        <translation>Herstart de video nadat hij is afgelopen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Specify how you would like to handle events like mouse clicks or keypresses. When set, this overrides the Duration attribute</source>
        <translation>Geef aan hoe u gebeurtenissen zoals muisklikken of toetsaanslagen wilt afhandelen. Wanneer ingesteld, overschrijft dit het Duur-attribuut</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Video file</source>
        <translation>Videobestand</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Maintains the aspect ratio</source>
        <translation>Behoudt de beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Call custom Python code</source>
        <translation>Aangepaste Python-code aanroepen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>When to call custom event handling code (if any)</source>
        <translation>Wanneer aangepaste gebeurtenisverwerkingscode aan te roepen (indien aanwezig)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>The library to use for sound rendering (recommended: sounddevice)</source>
        <translation>De bibliotheek om te gebruiken voor geluidsweergave (aanbevolen: sounddevice)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Copyright (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Auteursrecht (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Loop</source>
        <translation>Herhalen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Sound renderer</source>
        <translation>Geluidsrenderer</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Visual stimuli</source>
        <translation>Visuele stimuli</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A value in milliseconds, 'sound', 'mouseclick', or 'keypress'</source>
        <translation>Een waarde in milliseconden, 'sound', 'mouseclick', of 'keypress'</translation>
    </message>
</context>
</TS>