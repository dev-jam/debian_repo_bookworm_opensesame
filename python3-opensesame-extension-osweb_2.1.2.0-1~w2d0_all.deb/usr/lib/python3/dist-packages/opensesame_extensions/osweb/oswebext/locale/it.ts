<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>Experiment started in external browser</source>
        <translation>Esperimento avviato in browser esterno</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Save as…</source>
        <translation>Salva con nome..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>OSWeb and JATOS control panel</source>
        <translation>Pannello di controllo di OSWeb e JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Create online experiments</source>
        <translation>Crea esperimenti online</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Open from MindProbe</source>
        <translation>Apri da MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Open from JATOS</source>
        <translation>Apri da JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Experiment has been published to JATOS</source>
        <translation>L'esperimento è stato pubblicato su JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Select OSWeb results file…</source>
        <translation>Seleziona il file dei risultati di OSWeb…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Hai cambiato il nome dell'esperimento. Vuoi anche scollegare l'esperimento da JATOS (resettando l'UUID) in modo da poter creare un nuovo esperimento remoto?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Save and publish to JATOS</source>
        <translation>Salva e pubblica su JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Unlink from JATOS</source>
        <translation>Scollegare da JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Save and publish to MindProbe</source>
        <translation>Salva e pubblica su MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>You have saved the experiment under a different file name. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Hai salvato l'esperimento sotto un nome di file diverso. Vuoi anche scollegare l'esperimento da JATOS (resettando l'UUID) in modo da poter creare un nuovo esperimento remoto?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Downloading …</source>
        <translation>Scaricamento ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Uploading …</source>
        <translation>Caricamento ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Hide</source>
        <translation>Nascondi</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Please wait …</source>
        <translation>Per favore aspetta ..</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>ICONA</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="136" />
        <source>Actions</source>
        <translation>Azioni</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="181" />
        <source>Experiment properties</source>
        <translation>Proprietà dell'esperimento</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="199" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Seleziona il backend di OSWeb per eseguire nel browser&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="215" />
        <source>Open from JATOS</source>
        <translation>Apri da JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="227" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Scarica l'esperimento direttamente da JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="265" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>Converti i risultati di OSWeb in .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="277" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Converti il file dei risultati di JATOS in formato foglio di calcolo&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="305" />
        <source>Import from JATOS archive</source>
        <translation>Importa dall'archivio JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="318" />
        <source>Export to JATOS archive</source>
        <translation>Esporta nell'archivio JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="331" />
        <source>Export to HTML</source>
        <translation>Esporta in HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="343" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Apri l'esperimento dal file jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="355" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Salva l'esperimento come file jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="367" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Salva l'esperimento come file HTML autonomo&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb e pannello di controllo JATOS&lt;/b&gt;&lt;br /&gt;Opzioni per esperimenti online e sincronizzazione JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="240" />
        <source>Save and publish to JATOS</source>
        <translation>Salva e pubblica su JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="252" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Salva l'esperimento e caricalo direttamente su JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="126" />
        <source>&lt;h2 style="color:#78909c"&gt;To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;Per pubblicare esperimenti direttamente su JATOS, specifica un server e un token API qui sotto&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>Incorpora HTML personalizzato</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>An HTML editor widget</source>
        <translation>Un widget editor HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>HTML editor</source>
        <translation>Editor HTML</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>Esegue il codice JavaScript</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>Possibili numeri di soggetti</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Esegui l'esperimento anche se il controllo di compatibilità fallisce&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Appare sulla schermata di benvenuto di OSWeb.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>Mostra la schermata di benvenuto di OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Caricato quando inizia l'esperimento&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>Bypassa il controllo di compatibilità</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>Testo di benvenuto</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Si applica solo all'esportazione&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>Non fornire mai informazioni personali o sensibili come numeri di carta di credito o codici PIN. Clicca o tocca lo schermo per iniziare!</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>Un URL per riga</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>Librerie esterne</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Necessario per la riproduzione dei media affidabile&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>Mettete il browser a schermo intero</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="305" />
        <source>JATOS UUID</source>
        <translation>UUID di JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Visita &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; per richiedere un account gratuito&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387" />
        <source>JATOS server</source>
        <translation>Server JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="435" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="403" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="330" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Identifica l'esperimento su JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="318" />
        <source>undefined</source>
        <translation>indefinito</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>JATOS API token</source>
        <translation>Token API di JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="447" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Disponibile dal profilo utente di JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="337" />
        <source>Clear UUID</source>
        <translation>Cancella UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="353" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Azzera il collegamento tra l'esperimento e JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>Applica il colore di sfondo alla scheda del browser completa</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="460" />
        <source>Ignore conflicts</source>
        <translation>Ignora i conflitti</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="472" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Sovrascrive i file in conflitto durante la pubblicazione. Questa opzione viene reimpostata automaticamente.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb: Configure how the experiment runs in the browser</source>
        <translation>OSWeb: Configura come l'esperimento viene eseguito nel browser</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;OSWeb è una libreria JavaScript per eseguire esperimenti OpenSesame in un browser Web.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS: Configure experiment properties on the server</source>
        <translation>JATOS: Configura le proprietà dell'esperimento sul server</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS end-redirect URL</source>
        <translation>URL di reindirizzamento finale di JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="286" />
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="298" />
        <source>&lt;small  style="color:#78909c"&gt;Notifies participant platform (Sona Systems, Prolific, etc.) when experiment finishes&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;Notifica la piattaforma dei partecipanti (Sona Systems, Prolific, ecc.) quando l'esperimento termina&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="369" />
        <source>JATOS: Configure the server</source>
        <translation>JATOS: Configura il server</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="484" />
        <source>&lt;small  style="color:#78909c"&gt;JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;JATOS è un software di server per gestire esperimenti online. Hai bisogno di un account su un server JATOS, come mindprobe.eu, per eseguire esperimenti online. È necessario inserire un token API JATOS per collegare OpenSesame a JATOS. Visita la documentazione di OpenSesame per le istruzioni.&lt;/small&gt;</translation>
    </message>
</context>
</TS>