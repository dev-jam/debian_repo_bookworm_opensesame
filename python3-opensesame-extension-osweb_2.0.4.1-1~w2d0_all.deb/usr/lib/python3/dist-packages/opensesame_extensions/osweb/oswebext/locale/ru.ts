<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Experiment started in external browser</source>
        <translation>Эксперимент начался во внешнем браузере</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Save as…</source>
        <translation>Сохранить как..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>OSWeb and JATOS control panel</source>
        <translation>Панель управления OSWeb и JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Create online experiments</source>
        <translation>Создать онлайн-эксперименты</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Open from MindProbe</source>
        <translation>Открыть из MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Open from JATOS</source>
        <translation>Открыть из JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Open</source>
        <translation>открыть</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Experiment has been published to JATOS</source>
        <translation>Эксперимент опубликован в JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Select OSWeb results file…</source>
        <translation>Выберите файл результатов OSWeb…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Browse</source>
        <translation>Просмотр</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Вы изменили название эксперимента. Вы также хотите отвязать эксперимент от JATOS (сбросив UUID), чтобы вы могли создать новый удаленный эксперимент?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Save and publish to JATOS</source>
        <translation>Сохранить и опубликовать в JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Unlink from JATOS</source>
        <translation>Отвязать от JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Save and publish to MindProbe</source>
        <translation>Сохранить и опубликовать в MindProbe</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>Иконка</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="121" />
        <source>Actions</source>
        <translation>Действия</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="166" />
        <source>Experiment properties</source>
        <translation>Свойства эксперимента</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="184" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Выберите бэкэнд OSWeb для запуска в браузере&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="200" />
        <source>Open from JATOS</source>
        <translation>Открыть из JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="212" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Скачайте эксперимент прямо с JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="250" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>Конвертируйте результаты OSWeb в .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="262" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Преобразуйте файл результатов JATOS в формат таблицы&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="290" />
        <source>Import from JATOS archive</source>
        <translation>Импорт из архива JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="303" />
        <source>Export to JATOS archive</source>
        <translation>Экспорт в архив JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="316" />
        <source>Export to HTML</source>
        <translation>Экспорт в HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="328" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Открыть эксперимент из файла jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="340" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Сохранить эксперимент как файл jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="352" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Сохранить эксперимент как самостоятельный html-файл&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;Панель управления OSWeb и JATOS&lt;/b&gt;&lt;br /&gt;Варианты для онлайн-экспериментов и синхронизации JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="96" />
        <source>&lt;h2 style="color:#78909c"&gt;&amp;#x1F6C8; To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;&amp;#x1F6C8; Чтобы опубликовать эксперименты прямо в JATOS, укажите сервер и токен API ниже&lt;/h2&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="225" />
        <source>Save and publish to JATOS</source>
        <translation>Сохранить и опубликовать в JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="237" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Сохраните эксперимент и загрузите его прямо на JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>Встраивает пользовательский HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>An HTML editor widget</source>
        <translation>Виджет редактора HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>HTML editor</source>
        <translation>HTML-редактор</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>Выполняет код JavaScript</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>Возможные номера субъектов</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Запускать эксперимент, даже если проверка совместимости не удалась&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Появляется на приветственном экране OSWeb.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>Показать приветственный экран OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Загружается при начале эксперимента&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>Пропустить проверку совместимости</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>Приветственный текст</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Применяется только при экспорте&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>Никогда не предоставляйте личную или конфиденциальную информацию, такую как номера кредитных карт или пин-коды. Нажмите или коснитесь экрана, чтобы начать!</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>Один URL в строку</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>Внешние библиотеки</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Требуется для надежного воспроизведения мультимедиа&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>Сделать браузер на полный экран</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS</source>
        <translation>JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="316" />
        <source>JATOS UUID</source>
        <translation>UUID JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="309" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Перейдите на &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; чтобы запросить бесплатный аккаунт&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="377" />
        <source>JATOS server</source>
        <translation>Сервер JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="405" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="285" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="297" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Определяет эксперимент на JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="370" />
        <source>undefined</source>
        <translation>неопределено</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="412" />
        <source>JATOS API token</source>
        <translation>Токен API JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="342" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Доступно из профиля пользователя JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="326" />
        <source>Clear UUID</source>
        <translation>Очистить UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="360" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Сбрасывает связь между экспериментом и JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>Применить цвет фона ко всей вкладке браузера</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;&amp;#x1F6C8; OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;&amp;#x1F6C8; OSWeb — это библиотека JavaScript для запуска экспериментов OpenSesame в веб-браузере.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="392" />
        <source>&lt;small  style="color:#78909c"&gt;&amp;#x1F6C8; JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;&amp;#x1F6C8; JATOS — это серверное программное обеспечение для управления онлайн-экспериментами. Вам нужен аккаунт на сервере JATOS, таком как mindprobe.eu, чтобы проводить эксперименты в Интернете. Вам нужно ввести токен API JATOS, чтобы подключить OpenSesame к JATOS. Посетите документацию OpenSesame для получения инструкций.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>Ignore conflicts</source>
        <translation>Игнорировать конфликты</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="434" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Перезаписывает конфликтующие файлы при публикации. Этот параметр автоматически сбрасывается.&lt;/small&gt;</translation>
    </message>
</context>
</TS>